"use client"

import { useState } from "react"
import { NavLink } from "react-router-dom"
import { FaHome, FaChartBar, FaTasks, FaCalendarAlt, FaChartLine, FaBars } from "react-icons/fa"
import "./Sidebar.css"

const Sidebar = ({ expanded, toggleSidebar }) => {
  const [hovered, setHovered] = useState(false)

  const handleMouseEnter = () => {
    if (!expanded) {
      setHovered(true)
    }
  }

  const handleMouseLeave = () => {
    if (!expanded) {
      setHovered(false)
    }
  }

  const isExpanded = expanded || hovered

  return (
    <aside
      className={`sidebar ${isExpanded ? "expanded" : ""}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      aria-expanded={isExpanded}
      role="navigation"
      aria-label="Main Navigation"
    >
      <div className="sidebar-header">
        <button
          className="toggle-btn"
          onClick={toggleSidebar}
          aria-label={expanded ? "Collapse sidebar" : "Expand sidebar"}
        >
          <FaBars />
        </button>
        {isExpanded && <h1 className="logo">FMS</h1>}
      </div>
      <nav className="sidebar-nav">
        <ul>
          <li>
            <NavLink
              to="/"
              className={({ isActive }) => (isActive ? "active" : "")}
              aria-label="Dashboard"
              title="Dashboard"
            >
              <span className="icon">
                <FaHome />
              </span>
              {isExpanded && <span className="text">Dashboard</span>}
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/analytics"
              className={({ isActive }) => (isActive ? "active" : "")}
              aria-label="Analytics"
              title="Analytics"
            >
              <span className="icon">
                <FaChartBar />
              </span>
              {isExpanded && <span className="text">Analytics</span>}
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/tasks"
              className={({ isActive }) => (isActive ? "active" : "")}
              aria-label="Tasks"
              title="Tasks"
            >
              <span className="icon">
                <FaTasks />
              </span>
              {isExpanded && <span className="text">Tasks</span>}
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/calendar"
              className={({ isActive }) => (isActive ? "active" : "")}
              aria-label="Calendar"
              title="Calendar"
            >
              <span className="icon">
                <FaCalendarAlt />
              </span>
              {isExpanded && <span className="text">Calendar</span>}
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/prediction"
              className={({ isActive }) => (isActive ? "active" : "")}
              aria-label="Prediction"
              title="Prediction"
            >
              <span className="icon">
                <FaChartLine />
              </span>
              {isExpanded && <span className="text">Prediction</span>}
            </NavLink>
          </li>
        </ul>
      </nav>
      <div className="sidebar-footer">{isExpanded && <p>Facility Management System</p>}</div>
    </aside>
  )
}

export default Sidebar

