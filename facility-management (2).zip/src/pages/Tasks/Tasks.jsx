"use client"

import { useState, useEffect } from "react"
import {
  FaPlus,
  FaFilter,
  FaSort,
  FaCheck,
  FaTimes,
  FaEllipsisV,
  FaCalendarAlt,
  FaListUl,
  FaUserAlt,
  FaBuilding,
  FaSearch,
} from "react-icons/fa"
import "./Tasks.css"

const Tasks = () => {
  const [viewMode, setViewMode] = useState("list")
  const [tasks, setTasks] = useState([])
  const [filteredTasks, setFilteredTasks] = useState([])
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterStaff, setFilterStaff] = useState("all")
  const [filterFacility, setFilterFacility] = useState("all")
  const [sortBy, setSortBy] = useState("dueDate")
  const [isLoading, setIsLoading] = useState(true)
  const [showAddTask, setShowAddTask] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    facility: "",
    priority: "medium",
    status: "pending",
    dueDate: new Date().toISOString().split("T")[0],
    assignedTo: "",
  })

  const staffMembers = [
    { id: 1, name: "John Doe" },
    { id: 2, name: "Jane Smith" },
    { id: 3, name: "Mike Johnson" },
    { id: 4, name: "Sarah Williams" },
    { id: 5, name: "Robert Brown" },
  ]

  const facilities = [
    { id: 1, name: "Building A" },
    { id: 2, name: "Building B" },
    { id: 3, name: "Building C" },
    { id: 4, name: "Exterior" },
  ]

  // Simulate fetching tasks
  useEffect(() => {
    const fetchTasks = async () => {
      // In a real app, this would be an API call
      setTimeout(() => {
        const today = new Date()
        const dummyTasks = []

        // Generate tasks
        for (let i = 0; i < 20; i++) {
          const taskDate = new Date(today)
          taskDate.setDate(today.getDate() + Math.floor(Math.random() * 14) - 7) // Tasks from a week ago to a week from now

          const staffMember = staffMembers[Math.floor(Math.random() * staffMembers.length)]
          const facility = facilities[Math.floor(Math.random() * facilities.length)]

          dummyTasks.push({
            id: i + 1,
            title: `Task ${i + 1}`,
            description: `This is a description for task ${i + 1}. It includes details about what needs to be done.`,
            date: taskDate,
            dueDate: taskDate.toISOString().split("T")[0],
            startTime: `${Math.floor(Math.random() * 8) + 8}:00`,
            endTime: `${Math.floor(Math.random() * 8) + 13}:00`,
            priority: ["low", "medium", "high"][Math.floor(Math.random() * 3)],
            status: ["pending", "in-progress", "completed"][Math.floor(Math.random() * 3)],
            assignedTo: staffMember,
            facility: facility,
          })
        }

        setTasks(dummyTasks)
        setFilteredTasks(dummyTasks)
        setIsLoading(false)
      }, 1000)
    }

    fetchTasks()
  }, [])

  // Apply filters and search
  useEffect(() => {
    let filtered = [...tasks]

    // Apply status filter
    if (filterStatus !== "all") {
      filtered = filtered.filter((task) => task.status === filterStatus)
    }

    // Apply staff filter
    if (filterStaff !== "all") {
      filtered = filtered.filter((task) => task.assignedTo.id === Number.parseInt(filterStaff))
    }

    // Apply facility filter
    if (filterFacility !== "all") {
      filtered = filtered.filter((task) => task.facility.id === Number.parseInt(filterFacility))
    }

    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (task) =>
          task.title.toLowerCase().includes(query) ||
          task.description.toLowerCase().includes(query) ||
          task.assignedTo.name.toLowerCase().includes(query) ||
          task.facility.name.toLowerCase().includes(query),
      )
    }

    // Apply sorting
    filtered.sort((a, b) => {
      if (sortBy === "dueDate") {
        return new Date(a.dueDate) - new Date(b.dueDate)
      } else if (sortBy === "priority") {
        const priorityOrder = { high: 1, medium: 2, low: 3 }
        return priorityOrder[a.priority] - priorityOrder[b.priority]
      } else if (sortBy === "facility") {
        return a.facility.name.localeCompare(b.facility.name)
      } else if (sortBy === "assignee") {
        return a.assignedTo.name.localeCompare(b.assignedTo.name)
      }
      return 0
    })

    setFilteredTasks(filtered)
  }, [filterStatus, filterStaff, filterFacility, sortBy, searchQuery, tasks])

  const handleViewModeChange = (mode) => {
    setViewMode(mode)
  }

  const handleFilterChange = (status) => {
    setFilterStatus(status)
  }

  const handleStaffFilterChange = (e) => {
    setFilterStaff(e.target.value)
  }

  const handleFacilityFilterChange = (e) => {
    setFilterFacility(e.target.value)
  }

  const handleSortChange = (sortOption) => {
    setSortBy(sortOption)
  }

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value)
  }

  const handleAddTask = () => {
    setShowAddTask(true)
  }

  const handleCancelAdd = () => {
    setShowAddTask(false)
    setNewTask({
      title: "",
      description: "",
      facility: "",
      priority: "medium",
      status: "pending",
      dueDate: new Date().toISOString().split("T")[0],
      assignedTo: "",
    })
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setNewTask((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmitTask = (e) => {
    e.preventDefault()

    // Find the selected staff member
    const selectedStaff =
      staffMembers.find((staff) => staff.id === Number.parseInt(newTask.assignedTo)) || staffMembers[0]

    // Find the selected facility
    const selectedFacility =
      facilities.find((facility) => facility.id === Number.parseInt(newTask.facility)) || facilities[0]

    const task = {
      id: tasks.length + 1,
      ...newTask,
      date: new Date(newTask.dueDate),
      assignedTo: selectedStaff,
      facility: selectedFacility,
      startTime: "09:00",
      endTime: "17:00",
    }

    setTasks((prev) => [...prev, task])
    setShowAddTask(false)
    setNewTask({
      title: "",
      description: "",
      facility: "",
      priority: "medium",
      status: "pending",
      dueDate: new Date().toISOString().split("T")[0],
      assignedTo: "",
    })
  }

  const handleStatusChange = (id, newStatus) => {
    setTasks((prev) => prev.map((task) => (task.id === id ? { ...task, status: newStatus } : task)))
  }

  // Group tasks by date for timeline view
  const getTasksByDate = () => {
    const groupedTasks = {}

    filteredTasks.forEach((task) => {
      const dateStr = task.date.toDateString()
      if (!groupedTasks[dateStr]) {
        groupedTasks[dateStr] = []
      }
      groupedTasks[dateStr].push(task)
    })

    // Sort tasks within each day by start time
    Object.keys(groupedTasks).forEach((date) => {
      groupedTasks[date].sort((a, b) => {
        return a.startTime.localeCompare(b.startTime)
      })
    })

    return groupedTasks
  }

  // Format date for display
  const formatDate = (dateStr) => {
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)

    if (date.toDateString() === today.toDateString()) {
      return "Today"
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow"
    } else {
      return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })
    }
  }

  const renderListView = () => {
    return (
      <div className="task-list">
        {filteredTasks.map((task) => (
          <div
            key={task.id}
            className={`task-card ${task.status === "completed" ? "completed" : ""} slide-in`}
            style={{ animationDelay: `${task.id * 0.05}s` }}
          >
            <div className="task-header">
              <h3 className="task-title">{task.title}</h3>
              <div className={`task-priority ${task.priority}`}>
                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
              </div>
            </div>

            <div className="task-body">
              <p className="task-description">{task.description}</p>
              <div className="task-details">
                <div className="task-detail">
                  <span className="detail-label">Facility:</span>
                  <span className="detail-value">{task.facility.name}</span>
                </div>
                <div className="task-detail">
                  <span className="detail-label">Due Date:</span>
                  <span className="detail-value">{new Date(task.dueDate).toLocaleDateString()}</span>
                </div>
                <div className="task-detail">
                  <span className="detail-label">Assigned To:</span>
                  <span className="detail-value">{task.assignedTo.name}</span>
                </div>
              </div>
            </div>

            <div className="task-footer">
              <div className="task-status">
                <span className="status-label">Status:</span>
                <span className={`status-badge ${task.status}`}>
                  {task.status === "in-progress"
                    ? "In Progress"
                    : task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                </span>
              </div>

              <div className="task-actions">
                {task.status !== "completed" && (
                  <button
                    className="task-action-btn complete-btn"
                    onClick={() => handleStatusChange(task.id, "completed")}
                    title="Mark as Completed"
                    aria-label="Mark as Completed"
                  >
                    <FaCheck />
                  </button>
                )}
                {task.status === "pending" && (
                  <button
                    className="task-action-btn progress-btn"
                    onClick={() => handleStatusChange(task.id, "in-progress")}
                    title="Mark as In Progress"
                    aria-label="Mark as In Progress"
                  >
                    <FaEllipsisV />
                  </button>
                )}
                {task.status === "completed" && (
                  <button
                    className="task-action-btn reopen-btn"
                    onClick={() => handleStatusChange(task.id, "pending")}
                    title="Reopen Task"
                    aria-label="Reopen Task"
                  >
                    <FaTimes />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  const renderTimelineView = () => {
    const tasksByDate = getTasksByDate()
    const sortedDates = Object.keys(tasksByDate).sort((a, b) => new Date(a) - new Date(b))

    return (
      <div className="timeline-view">
        {sortedDates.map((dateStr) => (
          <div key={dateStr} className="date-group fade-in">
            <h3 className="date-header">{formatDate(dateStr)}</h3>
            <div className="tasks-timeline">
              {tasksByDate[dateStr].map((task) => (
                <div key={task.id} className={`timeline-task ${task.status} priority-${task.priority}`}>
                  <div className="task-time">
                    {task.startTime} - {task.endTime}
                  </div>
                  <div className="task-content">
                    <h4 className="task-title">{task.title}</h4>
                    <p className="task-description">{task.description}</p>
                    <div className="task-details">
                      <span className="task-assignee">
                        <FaUserAlt /> {task.assignedTo.name}
                      </span>
                      <span className="task-facility">
                        <FaBuilding /> {task.facility.name}
                      </span>
                      <div className="task-actions">
                        {task.status !== "completed" && (
                          <button
                            className="task-action-btn complete-btn"
                            onClick={() => handleStatusChange(task.id, "completed")}
                            title="Mark as Completed"
                            aria-label="Mark as Completed"
                          >
                            <FaCheck />
                          </button>
                        )}
                        {task.status === "pending" && (
                          <button
                            className="task-action-btn progress-btn"
                            onClick={() => handleStatusChange(task.id, "in-progress")}
                            title="Mark as In Progress"
                            aria-label="Mark as In Progress"
                          >
                            <FaEllipsisV />
                          </button>
                        )}
                        {task.status === "completed" && (
                          <button
                            className="task-action-btn reopen-btn"
                            onClick={() => handleStatusChange(task.id, "pending")}
                            title="Reopen Task"
                            aria-label="Reopen Task"
                          >
                            <FaTimes />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="tasks-page fade-in">
      <div className="tasks-header">
        <h1 className="page-title">Task Management</h1>

        <div className="search-container">
          <div className="search-input-wrapper">
            <FaSearch className="search-icon" />
            <input
              type="text"
              className="search-input"
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={handleSearchChange}
              aria-label="Search tasks"
            />
          </div>
        </div>

        <div className="tasks-actions">
          <div className="view-mode-toggle">
            <button
              className={`view-mode-btn ${viewMode === "list" ? "active" : ""}`}
              onClick={() => handleViewModeChange("list")}
              aria-label="List View"
              title="List View"
            >
              <FaListUl /> List
            </button>
            <button
              className={`view-mode-btn ${viewMode === "timeline" ? "active" : ""}`}
              onClick={() => handleViewModeChange("timeline")}
              aria-label="Timeline View"
              title="Timeline View"
            >
              <FaCalendarAlt /> Timeline
            </button>
          </div>

          <div className="filter-sort-container">
            <div className="filter-dropdown">
              <button className="filter-btn" aria-haspopup="true" aria-expanded="false">
                <FaFilter /> Filter
              </button>
              <div className="dropdown-content" role="menu">
                <div className="dropdown-section">
                  <h4>Status</h4>
                  <button
                    className={filterStatus === "all" ? "active" : ""}
                    onClick={() => handleFilterChange("all")}
                    role="menuitem"
                  >
                    All Tasks
                  </button>
                  <button
                    className={filterStatus === "pending" ? "active" : ""}
                    onClick={() => handleFilterChange("pending")}
                    role="menuitem"
                  >
                    Pending
                  </button>
                  <button
                    className={filterStatus === "in-progress" ? "active" : ""}
                    onClick={() => handleFilterChange("in-progress")}
                    role="menuitem"
                  >
                    In Progress
                  </button>
                  <button
                    className={filterStatus === "completed" ? "active" : ""}
                    onClick={() => handleFilterChange("completed")}
                    role="menuitem"
                  >
                    Completed
                  </button>
                </div>

                <div className="dropdown-section">
                  <h4>Staff</h4>
                  <select
                    value={filterStaff}
                    onChange={handleStaffFilterChange}
                    className="dropdown-select"
                    aria-label="Filter by staff"
                  >
                    <option value="all">All Staff</option>
                    {staffMembers.map((staff) => (
                      <option key={staff.id} value={staff.id}>
                        {staff.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="dropdown-section">
                  <h4>Facility</h4>
                  <select
                    value={filterFacility}
                    onChange={handleFacilityFilterChange}
                    className="dropdown-select"
                    aria-label="Filter by facility"
                  >
                    <option value="all">All Facilities</option>
                    {facilities.map((facility) => (
                      <option key={facility.id} value={facility.id}>
                        {facility.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="sort-dropdown">
              <button className="sort-btn" aria-haspopup="true" aria-expanded="false">
                <FaSort /> Sort
              </button>
              <div className="dropdown-content" role="menu">
                <button
                  className={sortBy === "dueDate" ? "active" : ""}
                  onClick={() => handleSortChange("dueDate")}
                  role="menuitem"
                >
                  Due Date
                </button>
                <button
                  className={sortBy === "priority" ? "active" : ""}
                  onClick={() => handleSortChange("priority")}
                  role="menuitem"
                >
                  Priority
                </button>
                <button
                  className={sortBy === "facility" ? "active" : ""}
                  onClick={() => handleSortChange("facility")}
                  role="menuitem"
                >
                  Facility
                </button>
                <button
                  className={sortBy === "assignee" ? "active" : ""}
                  onClick={() => handleSortChange("assignee")}
                  role="menuitem"
                >
                  Assignee
                </button>
              </div>
            </div>
          </div>

          <button className="add-task-btn" onClick={handleAddTask} aria-label="Add Task">
            <FaPlus /> Add Task
          </button>
        </div>
      </div>

      {showAddTask && (
        <div className="add-task-form-container slide-in">
          <form className="add-task-form" onSubmit={handleSubmitTask}>
            <h2>Add New Task</h2>

            <div className="form-group">
              <label htmlFor="title">Title</label>
              <input
                type="text"
                id="title"
                name="title"
                value={newTask.title}
                onChange={handleInputChange}
                className="form-control"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={newTask.description}
                onChange={handleInputChange}
                className="form-control"
                rows="3"
              ></textarea>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="facility">Facility</label>
                <select
                  id="facility"
                  name="facility"
                  value={newTask.facility}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                >
                  <option value="">Select Facility</option>
                  {facilities.map((facility) => (
                    <option key={facility.id} value={facility.id}>
                      {facility.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="priority">Priority</label>
                <select
                  id="priority"
                  name="priority"
                  value={newTask.priority}
                  onChange={handleInputChange}
                  className="form-control"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="status">Status</label>
                <select
                  id="status"
                  name="status"
                  value={newTask.status}
                  onChange={handleInputChange}
                  className="form-control"
                >
                  <option value="pending">Pending</option>
                  <option value="in-progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="dueDate">Due Date</label>
                <input
                  type="date"
                  id="dueDate"
                  name="dueDate"
                  value={newTask.dueDate}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="assignedTo">Assigned To</label>
              <select
                id="assignedTo"
                name="assignedTo"
                value={newTask.assignedTo}
                onChange={handleInputChange}
                className="form-control"
                required
              >
                <option value="">Select Staff Member</option>
                {staffMembers.map((staff) => (
                  <option key={staff.id} value={staff.id}>
                    {staff.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-actions">
              <button type="button" className="btn btn-secondary" onClick={handleCancelAdd}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary">
                Add Task
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="tasks-container">
        {isLoading ? (
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading tasks...</p>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="no-tasks">
            <p>No tasks found. Try changing your filters or add a new task.</p>
          </div>
        ) : viewMode === "list" ? (
          renderListView()
        ) : (
          renderTimelineView()
        )}
      </div>
    </div>
  )
}

export default Tasks

