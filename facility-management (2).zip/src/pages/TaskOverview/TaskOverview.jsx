"use client"

import { useState, useEffect } from "react"
import { FaCalendarAlt, FaListUl, FaUserAlt, FaBuilding } from "react-icons/fa"
import "./TaskOverview.css"

const TaskOverview = () => {
  const [viewMode, setViewMode] = useState("daily")
  const [tasks, setTasks] = useState([])
  const [filteredTasks, setFilteredTasks] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [filterStaff, setFilterStaff] = useState("all")
  const [filterFacility, setFilterFacility] = useState("all")

  const staffMembers = [
    { id: 1, name: "John Doe" },
    { id: 2, name: "Jane Smith" },
    { id: 3, name: "Mike Johnson" },
    { id: 4, name: "Sarah Williams" },
    { id: 5, name: "Robert Brown" },
  ]

  const facilities = [
    { id: 1, name: "Building A" },
    { id: 2, name: "Building B" },
    { id: 3, name: "Building C" },
    { id: 4, name: "Exterior" },
  ]

  // Simulate fetching tasks
  useEffect(() => {
    const fetchTasks = async () => {
      // In a real app, this would be an API call
      setTimeout(() => {
        const today = new Date()
        const dummyTasks = []

        // Generate tasks for the current week
        for (let i = 0; i < 30; i++) {
          const taskDate = new Date(today)
          taskDate.setDate(today.getDate() + Math.floor(Math.random() * 7))

          const staffMember = staffMembers[Math.floor(Math.random() * staffMembers.length)]
          const facility = facilities[Math.floor(Math.random() * facilities.length)]

          dummyTasks.push({
            id: i + 1,
            title: `Task ${i + 1}`,
            description: `This is a description for task ${i + 1}`,
            date: taskDate,
            startTime: `${Math.floor(Math.random() * 8) + 8}:00`,
            endTime: `${Math.floor(Math.random() * 8) + 13}:00`,
            priority: ["low", "medium", "high"][Math.floor(Math.random() * 3)],
            status: ["pending", "in-progress", "completed"][Math.floor(Math.random() * 3)],
            assignedTo: staffMember,
            facility: facility,
          })
        }

        setTasks(dummyTasks)
        setFilteredTasks(dummyTasks)
        setIsLoading(false)
      }, 1000)
    }

    fetchTasks()
  }, [])

  // Apply filters when they change
  useEffect(() => {
    let filtered = [...tasks]

    if (filterStaff !== "all") {
      filtered = filtered.filter((task) => task.assignedTo.id === Number.parseInt(filterStaff))
    }

    if (filterFacility !== "all") {
      filtered = filtered.filter((task) => task.facility.id === Number.parseInt(filterFacility))
    }

    setFilteredTasks(filtered)
  }, [filterStaff, filterFacility, tasks])

  const handleViewModeChange = (mode) => {
    setViewMode(mode)
  }

  const handleStaffFilterChange = (e) => {
    setFilterStaff(e.target.value)
  }

  const handleFacilityFilterChange = (e) => {
    setFilterFacility(e.target.value)
  }

  // Group tasks by date for daily view
  const getTasksByDate = () => {
    const groupedTasks = {}

    filteredTasks.forEach((task) => {
      const dateStr = task.date.toDateString()
      if (!groupedTasks[dateStr]) {
        groupedTasks[dateStr] = []
      }
      groupedTasks[dateStr].push(task)
    })

    // Sort tasks within each day by start time
    Object.keys(groupedTasks).forEach((date) => {
      groupedTasks[date].sort((a, b) => {
        return a.startTime.localeCompare(b.startTime)
      })
    })

    return groupedTasks
  }

  // Group tasks by staff member for weekly view
  const getTasksByStaff = () => {
    const groupedTasks = {}

    staffMembers.forEach((staff) => {
      groupedTasks[staff.id] = {
        staff,
        tasks: filteredTasks.filter((task) => task.assignedTo.id === staff.id),
      }
    })

    return groupedTasks
  }

  // Format date for display
  const formatDate = (dateStr) => {
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)

    if (date.toDateString() === today.toDateString()) {
      return "Today"
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow"
    } else {
      return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })
    }
  }

  const renderDailyView = () => {
    const tasksByDate = getTasksByDate()
    const sortedDates = Object.keys(tasksByDate).sort((a, b) => new Date(a) - new Date(b))

    return (
      <div className="daily-view">
        {sortedDates.map((dateStr) => (
          <div key={dateStr} className="date-group fade-in">
            <h3 className="date-header">{formatDate(dateStr)}</h3>
            <div className="tasks-timeline">
              {tasksByDate[dateStr].map((task) => (
                <div key={task.id} className={`timeline-task ${task.status} priority-${task.priority}`}>
                  <div className="task-time">
                    {task.startTime} - {task.endTime}
                  </div>
                  <div className="task-content">
                    <h4 className="task-title">{task.title}</h4>
                    <p className="task-description">{task.description}</p>
                    <div className="task-details">
                      <span className="task-assignee">
                        <FaUserAlt /> {task.assignedTo.name}
                      </span>
                      <span className="task-facility">
                        <FaBuilding /> {task.facility.name}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    )
  }

  const renderWeeklyView = () => {
    const tasksByStaff = getTasksByStaff()

    return (
      <div className="weekly-view">
        {Object.values(tasksByStaff).map(({ staff, tasks }) => (
          <div key={staff.id} className="staff-group fade-in">
            <h3 className="staff-header">{staff.name}</h3>
            <div className="weekly-calendar">
              {Array.from({ length: 7 }).map((_, dayIndex) => {
                const date = new Date()
                date.setDate(date.getDate() + dayIndex)
                const dateStr = date.toDateString()

                const dayTasks = tasks.filter((task) => task.date.toDateString() === dateStr)

                return (
                  <div key={dayIndex} className="calendar-day">
                    <div className="day-header">
                      {date.toLocaleDateString("en-US", { weekday: "short" })}
                      <span className="day-number">{date.getDate()}</span>
                    </div>
                    <div className="day-tasks">
                      {dayTasks.length === 0 ? (
                        <div className="no-tasks">No tasks</div>
                      ) : (
                        dayTasks.map((task) => (
                          <div key={task.id} className={`day-task ${task.status} priority-${task.priority}`}>
                            <div className="task-time">{task.startTime}</div>
                            <div className="task-title">{task.title}</div>
                            <div className="task-facility">{task.facility.name}</div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="task-overview-page fade-in">
      <div className="task-overview-header">
        <h1 className="page-title">Task Overview</h1>
        <div className="task-overview-actions">
          <div className="view-mode-toggle">
            <button
              className={`view-mode-btn ${viewMode === "daily" ? "active" : ""}`}
              onClick={() => handleViewModeChange("daily")}
            >
              <FaListUl /> Daily View
            </button>
            <button
              className={`view-mode-btn ${viewMode === "weekly" ? "active" : ""}`}
              onClick={() => handleViewModeChange("weekly")}
            >
              <FaCalendarAlt /> Weekly View
            </button>
          </div>

          <div className="filters">
            <div className="filter">
              <label htmlFor="staffFilter">
                <FaUserAlt /> Staff:
              </label>
              <select id="staffFilter" value={filterStaff} onChange={handleStaffFilterChange}>
                <option value="all">All Staff</option>
                {staffMembers.map((staff) => (
                  <option key={staff.id} value={staff.id}>
                    {staff.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter">
              <label htmlFor="facilityFilter">
                <FaBuilding /> Facility:
              </label>
              <select id="facilityFilter" value={filterFacility} onChange={handleFacilityFilterChange}>
                <option value="all">All Facilities</option>
                {facilities.map((facility) => (
                  <option key={facility.id} value={facility.id}>
                    {facility.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="task-overview-content">
        {isLoading ? (
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading tasks...</p>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="no-tasks-message">
            <p>No tasks found with the current filters.</p>
          </div>
        ) : viewMode === "daily" ? (
          renderDailyView()
        ) : (
          renderWeeklyView()
        )}
      </div>
    </div>
  )
}

export default TaskOverview

