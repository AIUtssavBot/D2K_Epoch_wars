"use client"

import { useState } from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Sidebar from "./components/Sidebar/Sidebar"
import Dashboard from "./pages/Dashboard/Dashboard"
import Analytics from "./pages/Analytics/Analytics"
import Tasks from "./pages/Tasks/Tasks" // This will be our merged tasks page
import Calendar from "./pages/Calendar/Calendar"
import Prediction from "./pages/Prediction/Prediction"
import "./App.css"

function App() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false)

  const toggleSidebar = () => {
    setSidebarExpanded(!sidebarExpanded)
  }

  return (
    <Router>
      <div className="app-container">
        <Sidebar expanded={sidebarExpanded} toggleSidebar={toggleSidebar} />
        <main className={`main-content ${sidebarExpanded ? "sidebar-expanded" : ""}`}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/prediction" element={<Prediction />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

