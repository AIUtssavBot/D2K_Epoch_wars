"use client"

import { useState } from "react"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import Sidebar from "./components/Sidebar/Sidebar"
import Dashboard from "./pages/Dashboard/Dashboard"
import Analytics from "./pages/Analytics/Analytics"
import Tasks from "./pages/Tasks/Tasks"
import Calendar from "./pages/Calendar/Calendar"
import Prediction from "./pages/Prediction/Prediction"
import TaskOverview from "./pages/TaskOverview/TaskOverview"
import Home from "./pages/Home/Home"
import Login from "./pages/Login/Login"
import Signup from "./pages/Signup/Signup"
import "./App.css"

function App() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const toggleSidebar = () => {
    setSidebarExpanded(!sidebarExpanded)
  }

  // For demo purposes, we'll consider the user authenticated if they visit any protected route
  // In a real app, you would implement proper authentication
  const handleAuthentication = () => {
    setIsAuthenticated(true)
  }

  return (
    <Router>
      <div className="app-container">
        {isAuthenticated && <Sidebar expanded={sidebarExpanded} toggleSidebar={toggleSidebar} />}
        <main
          className={`main-content ${isAuthenticated ? (sidebarExpanded ? "sidebar-expanded" : "") : "no-sidebar"}`}
        >
          <Routes>
            {/* Public routes */}
            <Route path="/home" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* Protected routes */}
            <Route path="/" element={isAuthenticated ? <Dashboard /> : <Navigate to="/home" replace />} />
            <Route
              path="/analytics"
              element={
                isAuthenticated ? <Analytics /> : <Navigate to="/login" replace onClick={handleAuthentication} />
              }
            />
            <Route
              path="/tasks"
              element={isAuthenticated ? <Tasks /> : <Navigate to="/login" replace onClick={handleAuthentication} />}
            />
            <Route
              path="/calendar"
              element={isAuthenticated ? <Calendar /> : <Navigate to="/login" replace onClick={handleAuthentication} />}
            />
            <Route
              path="/prediction"
              element={
                isAuthenticated ? <Prediction /> : <Navigate to="/login" replace onClick={handleAuthentication} />
              }
            />
            <Route
              path="/task-overview"
              element={
                isAuthenticated ? <TaskOverview /> : <Navigate to="/login" replace onClick={handleAuthentication} />
              }
            />

            {/* Redirect root to home if not authenticated */}
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App

