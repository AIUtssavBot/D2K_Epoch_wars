"use client"

import { useState, useEffect } from "react"
import { FaPlus, FaFilter, FaSort, FaCheck, FaTimes, FaEllipsisV } from "react-icons/fa"
import "./Tasks.css"

const Tasks = () => {
  const [tasks, setTasks] = useState([])
  const [filteredTasks, setFilteredTasks] = useState([])
  const [filterStatus, setFilterStatus] = useState("all")
  const [sortBy, setSortBy] = useState("dueDate")
  const [isLoading, setIsLoading] = useState(true)
  const [showAddTask, setShowAddTask] = useState(false)
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    facility: "",
    priority: "medium",
    status: "pending",
    dueDate: new Date().toISOString().split("T")[0],
  })

  // Simulate fetching tasks
  useEffect(() => {
    const fetchTasks = async () => {
      // In a real app, this would be an API call
      setTimeout(() => {
        const dummyTasks = [
          {
            id: 1,
            title: "HVAC Maintenance",
            description: "Regular maintenance check for HVAC systems in Building A",
            facility: "Building A",
            priority: "high",
            status: "in-progress",
            dueDate: "2025-03-25",
            assignedTo: "John Doe",
          },
          {
            id: 2,
            title: "Plumbing Repair",
            description: "Fix leaking pipe in restroom on 2nd floor",
            facility: "Building B",
            priority: "high",
            status: "pending",
            dueDate: "2025-03-24",
            assignedTo: "Jane Smith",
          },
          {
            id: 3,
            title: "Electrical Inspection",
            description: "Annual electrical system inspection",
            facility: "Building C",
            priority: "medium",
            status: "completed",
            dueDate: "2025-03-20",
            assignedTo: "Mike Johnson",
          },
          {
            id: 4,
            title: "Landscaping",
            description: "Trim trees and bushes around the facility",
            facility: "Exterior",
            priority: "low",
            status: "pending",
            dueDate: "2025-03-28",
            assignedTo: "Sarah Williams",
          },
          {
            id: 5,
            title: "Security System Update",
            description: "Update security cameras and access control systems",
            facility: "All Buildings",
            priority: "high",
            status: "pending",
            dueDate: "2025-03-26",
            assignedTo: "Robert Brown",
          },
        ]
        setTasks(dummyTasks)
        setFilteredTasks(dummyTasks)
        setIsLoading(false)
      }, 1000)
    }

    fetchTasks()
  }, [])

  // Filter tasks when filterStatus changes
  useEffect(() => {
    if (filterStatus === "all") {
      setFilteredTasks(tasks)
    } else {
      setFilteredTasks(tasks.filter((task) => task.status === filterStatus))
    }
  }, [filterStatus, tasks])

  // Sort tasks when sortBy changes
  useEffect(() => {
    const sortedTasks = [...filteredTasks].sort((a, b) => {
      if (sortBy === "dueDate") {
        return new Date(a.dueDate) - new Date(b.dueDate)
      } else if (sortBy === "priority") {
        const priorityOrder = { high: 1, medium: 2, low: 3 }
        return priorityOrder[a.priority] - priorityOrder[b.priority]
      } else if (sortBy === "facility") {
        return a.facility.localeCompare(b.facility)
      }
      return 0
    })
    setFilteredTasks(sortedTasks)
  }, [sortBy])

  const handleFilterChange = (status) => {
    setFilterStatus(status)
  }

  const handleSortChange = (sortOption) => {
    setSortBy(sortOption)
  }

  const handleAddTask = () => {
    setShowAddTask(true)
  }

  const handleCancelAdd = () => {
    setShowAddTask(false)
    setNewTask({
      title: "",
      description: "",
      facility: "",
      priority: "medium",
      status: "pending",
      dueDate: new Date().toISOString().split("T")[0],
    })
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setNewTask((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmitTask = (e) => {
    e.preventDefault()
    const task = {
      id: tasks.length + 1,
      ...newTask,
      assignedTo: "Unassigned",
    }
    setTasks((prev) => [...prev, task])
    setShowAddTask(false)
    setNewTask({
      title: "",
      description: "",
      facility: "",
      priority: "medium",
      status: "pending",
      dueDate: new Date().toISOString().split("T")[0],
    })
  }

  const handleStatusChange = (id, newStatus) => {
    setTasks((prev) => prev.map((task) => (task.id === id ? { ...task, status: newStatus } : task)))
  }

  return (
    <div className="tasks-page fade-in">
      <div className="tasks-header">
        <h1 className="page-title">Task Management</h1>
        <div className="tasks-actions">
          <div className="filter-sort-container">
            <div className="filter-dropdown">
              <button className="filter-btn">
                <FaFilter /> Filter
              </button>
              <div className="dropdown-content">
                <button className={filterStatus === "all" ? "active" : ""} onClick={() => handleFilterChange("all")}>
                  All Tasks
                </button>
                <button
                  className={filterStatus === "pending" ? "active" : ""}
                  onClick={() => handleFilterChange("pending")}
                >
                  Pending
                </button>
                <button
                  className={filterStatus === "in-progress" ? "active" : ""}
                  onClick={() => handleFilterChange("in-progress")}
                >
                  In Progress
                </button>
                <button
                  className={filterStatus === "completed" ? "active" : ""}
                  onClick={() => handleFilterChange("completed")}
                >
                  Completed
                </button>
              </div>
            </div>

            <div className="sort-dropdown">
              <button className="sort-btn">
                <FaSort /> Sort
              </button>
              <div className="dropdown-content">
                <button className={sortBy === "dueDate" ? "active" : ""} onClick={() => handleSortChange("dueDate")}>
                  Due Date
                </button>
                <button className={sortBy === "priority" ? "active" : ""} onClick={() => handleSortChange("priority")}>
                  Priority
                </button>
                <button className={sortBy === "facility" ? "active" : ""} onClick={() => handleSortChange("facility")}>
                  Facility
                </button>
              </div>
            </div>
          </div>

          <button className="add-task-btn" onClick={handleAddTask}>
            <FaPlus /> Add Task
          </button>
        </div>
      </div>

      {showAddTask && (
        <div className="add-task-form-container slide-in">
          <form className="add-task-form" onSubmit={handleSubmitTask}>
            <h2>Add New Task</h2>

            <div className="form-group">
              <label htmlFor="title">Title</label>
              <input
                type="text"
                id="title"
                name="title"
                value={newTask.title}
                onChange={handleInputChange}
                className="form-control"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={newTask.description}
                onChange={handleInputChange}
                className="form-control"
                rows="3"
              ></textarea>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="facility">Facility</label>
                <input
                  type="text"
                  id="facility"
                  name="facility"
                  value={newTask.facility}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="priority">Priority</label>
                <select
                  id="priority"
                  name="priority"
                  value={newTask.priority}
                  onChange={handleInputChange}
                  className="form-control"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="status">Status</label>
                <select
                  id="status"
                  name="status"
                  value={newTask.status}
                  onChange={handleInputChange}
                  className="form-control"
                >
                  <option value="pending">Pending</option>
                  <option value="in-progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="dueDate">Due Date</label>
                <input
                  type="date"
                  id="dueDate"
                  name="dueDate"
                  value={newTask.dueDate}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="button" className="btn btn-secondary" onClick={handleCancelAdd}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary">
                Add Task
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="tasks-container">
        {isLoading ? (
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p>Loading tasks...</p>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="no-tasks">
            <p>No tasks found. Try changing your filters or add a new task.</p>
          </div>
        ) : (
          <div className="task-list">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                className={`task-card ${task.status === "completed" ? "completed" : ""} slide-in`}
                style={{ animationDelay: `${task.id * 0.1}s` }}
              >
                <div className="task-header">
                  <h3 className="task-title">{task.title}</h3>
                  <div className={`task-priority ${task.priority}`}>
                    {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                  </div>
                </div>

                <div className="task-body">
                  <p className="task-description">{task.description}</p>
                  <div className="task-details">
                    <div className="task-detail">
                      <span className="detail-label">Facility:</span>
                      <span className="detail-value">{task.facility}</span>
                    </div>
                    <div className="task-detail">
                      <span className="detail-label">Due Date:</span>
                      <span className="detail-value">{new Date(task.dueDate).toLocaleDateString()}</span>
                    </div>
                    <div className="task-detail">
                      <span className="detail-label">Assigned To:</span>
                      <span className="detail-value">{task.assignedTo}</span>
                    </div>
                  </div>
                </div>

                <div className="task-footer">
                  <div className="task-status">
                    <span className="status-label">Status:</span>
                    <span className={`status-badge ${task.status}`}>
                      {task.status === "in-progress"
                        ? "In Progress"
                        : task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                    </span>
                  </div>

                  <div className="task-actions">
                    {task.status !== "completed" && (
                      <button
                        className="task-action-btn complete-btn"
                        onClick={() => handleStatusChange(task.id, "completed")}
                        title="Mark as Completed"
                      >
                        <FaCheck />
                      </button>
                    )}
                    {task.status === "pending" && (
                      <button
                        className="task-action-btn progress-btn"
                        onClick={() => handleStatusChange(task.id, "in-progress")}
                        title="Mark as In Progress"
                      >
                        <FaEllipsisV />
                      </button>
                    )}
                    {task.status === "completed" && (
                      <button
                        className="task-action-btn reopen-btn"
                        onClick={() => handleStatusChange(task.id, "pending")}
                        title="Reopen Task"
                      >
                        <FaTimes />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Tasks

